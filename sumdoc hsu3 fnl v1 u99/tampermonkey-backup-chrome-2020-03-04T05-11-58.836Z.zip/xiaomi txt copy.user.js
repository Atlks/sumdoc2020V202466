// ==UserScript==
// @name         xiaomi txt copy
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match       https://i.mi.com/note/h5*
// @require https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js
// ==/UserScript==

(function() {




      console.log('----xiaomi page')
     console.log( $('div[class="note-list-items-2ID3T"]') )
    setTimeout(function(){
        console.log( $('div[class="note-list-items-2ID3T"]').text())
    },7000);

     console.log( $('div[class="note-list-items-2ID3T"]').html())

   //  console.log( $('div[class="note-list-items-2ID3T"]').html())
  //   console.log( $('div[class="note-list-items-2ID3T"]').text())

  //   console.log( $('body').text())
    // Your code here...
})();