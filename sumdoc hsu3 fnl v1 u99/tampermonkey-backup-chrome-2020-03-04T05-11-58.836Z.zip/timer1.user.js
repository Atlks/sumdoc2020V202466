// ==UserScript==
// @name         timer1
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://*/*
// @grant        none
// ==/UserScript==

(function() {
    setInterval(function(){

    //xxxxxx
    },3000)

    // Your code here...
})();