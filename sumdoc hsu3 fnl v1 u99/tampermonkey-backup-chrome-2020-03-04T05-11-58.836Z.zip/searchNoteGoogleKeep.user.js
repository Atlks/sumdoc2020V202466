// ==UserScript==
// @name         searchNoteGoogleKeep
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.google.com/search?q=*&atisch=y
// @grant unsafeWindow
// @grant GM_log
// @grant  GM_openInTab
// @grant  GM.xmlHttpRequest
// @grant GM_setValue
// @grant GM_getValue
// ==/UserScript==

(function() {
    keyword=getQueryVariable('q')
    kepurl='https://keep.google.com/#search/text%253D'+keyword
 //    https://keep.google.com/#search/text%253Daaa
    GM_openInTab(kepurl,true)


    docurl='https://docs.google.com/document/u/0/?q='+keyword
      GM_openInTab(docurl,true)


    drvurl='https://drive.google.com/drive/search?q='+keyword
     GM_openInTab(drvurl,true)


        emurl='https://mail.google.com/mail/u/0/#search/'+keyword
     GM_openInTab(emurl,true)

    evnturl='https://www.evernote.com/u/0/client/web#?query=view%3ASE%1E'+keyword
  GM_openInTab(evnturl,true)

    function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}
})();