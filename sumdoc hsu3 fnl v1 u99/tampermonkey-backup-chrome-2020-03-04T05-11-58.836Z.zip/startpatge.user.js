// ==UserScript==
// @name         startpatge
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://cn.pornhub.com/?start
// @grant unsafeWindow
// @grant GM_log
// @grant  GM_openInTab
// @grant  GM.xmlHttpRequest
// @grant GM_setValue
// @grant GM_getValue
// ==/UserScript==
// setItem

(function() {

    var lastRuntime;
    watchdogReset()

    //  console.__proto__.log("-------s")
    GM_log("staret  down...")
    var  alltabNum=0;
    GM_setValue('alltabNum', 0)
    setValInt('alltabNum', 0);
    //  jsonstr='[{"urlid":"/view_video.php?viewkey=1008110901"},{"urlid":"/view_video.php?viewkey=1027011661"},{"urlid":"/view_video.php?viewkey=1031923747"},{"urlid":"/view_video.php?viewkey=1032854684"},{"urlid":"/view_video.php?viewkey=1038116855"}]'
    //  setInterval("clock()",1000);
    getAjacData()
    setInterval(function(){      getAjacData()  },60*1000);
    setInterval(function(){

        console.log("  timer... ,now running num is"+ getValInt('alltabNum'))

    },5*1000);


    function watchdogFeed()
    {
        lastRuntime=new Date();
    }
    function watchdogReset()
    {
        lastRuntime=new Date();
        setValInt('alltabNum', 0 )
    }
    function watchdogCheck()
    {
        //  var date1= '2020/02/25 18:23:00';  //开始时间
        var now = new Date();    //结束时间
        var date3 = now.getTime() - lastRuntime.getTime();   //时间差的毫秒数
        //计算出相差天数
        var min=Math.floor(date3/( 1000*60))
         if(min>8)
        {
            watchdogReset()
        }
    }
    function   getAjacData()
    {
        watchdogCheck()


        alltabNum= getValInt('alltabNum')
        if(alltabNum>5)
        {
            GM_log("tomany tabs ,now numis"+ alltabNum)
            console.log("tomany tabs ,now numis"+ alltabNum)
            return;
        }
        watchdogFeed()

        GM.xmlHttpRequest({
            timeout:30000,
            method: "GET",
            url: "http://localhost:888/get7data",
            headers: {
                "User-Agent": "Mozilla/5.0",    // If not specified, navigator.userAgent will be used.
                "Accept": "text/xml"            // If not specified, browser defaults will be used.
            },
            onload: function(response) {

                actJsonstr(  response.responseText)
                console.log([
                    response.status,
                    response.statusText,
                    response.readyState,
                    response.responseHeaders,
                    response.responseText,
                    response.finalUrl

                ].join("\n"));
            },
            onerror:function(er){
                  console.log(er)
            },ontimeout:function(e){
               console.log(e)
            }
        });
    }

    function setValInt(keyname,v)
    {
        unsafeWindow.localStorage.setItem(keyname, v);
    }

    function getValInt(keyname)
    {
        return parseInt( unsafeWindow.localStorage.getItem(keyname))
    }

    function actJsonstr(jsonstr)
    {
        jsonarr=JSON.parse(jsonstr)
        for( it of jsonarr){
            url='https://cn.pornhub.com'+it.urlid
            console.log(url)
            GM_log(url)
            GM_openInTab(url,true)

            setValInt('alltabNum', getValInt('alltabNum')+1 )
            console.log("open a tabl ,now running task num is"+ getValInt('alltabNum'))
        }
    }

    // Your code here...
})();