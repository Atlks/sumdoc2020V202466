// ==UserScript==
// @name         closeAdpage
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://cp.ebbp1.pro./*
// @grant GM_log
// @grant unsafeWindow
// @grant  window.close
// @grant GM_setValue
// @grant GM_getValue
// @grant  GM.xmlHttpRequest
// ==/UserScript==

(function() {
     console.log('will close win')
      window.close()

    // Your code here...
})();