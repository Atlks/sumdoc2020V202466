// ==UserScript==
// @name         atischV2
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.google.com/search?q=*
// @grant unsafeWindow
// @grant GM_log
// @grant  GM_openInTab
// @grant  GM.xmlHttpRequest
// @grant GM_setValue
// @grant GM_getValue
// ==/UserScript==

(function() {

    console.log("--sch inj--");
    document.onkeydown=function(event){
        var e = event || window.event || arguments.callee.caller.arguments[0];


        if (e.keyCode == 83 && e.ctrlKey && e.shiftKey  && e.altKey) {
          // 、、 alert("你按下了ctrl+s");
             console.log("你按下了ctrl+s");
               keyword=getQueryVariable('q')
       //  window.location=' https://www.google.com/search?atisch=y&q='+keyword

            searchMore(keyword);
        }


    };


    function searchMore(keyword)
    {
        kepurl='https://keep.google.com/#search/text%253D'+keyword
        //    https://keep.google.com/#search/text%253Daaa
        GM_openInTab(kepurl,true)


        docurl='https://docs.google.com/document/u/0/?q='+keyword
        GM_openInTab(docurl,true)




        emurl='https://mail.google.com/mail/u/0/#search/'+keyword
        GM_openInTab(emurl,true)

        evnturl='https://www.evernote.com/u/0/client/web#?query=view%3ASE%1E'+keyword
        GM_openInTab(evnturl,true)



        drvurl='https://drive.google.com/drive/search?q='+keyword
        GM_openInTab(drvurl,true)



    }
    function getQueryVariable(variable)
{
 //   alert('search:: '+  window.location.search)
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}

    // Your code here...
})();