// ==UserScript==
// @name         downVdAtiV2
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://cn.pornhub.com/view_video.php?viewkey=*
// xxx  include    *
// @grant GM_log
// @grant unsafeWindow
// @grant  window.close
// @grant GM_setValue
// @grant GM_getValue
// @grant  GM.xmlHttpRequest
// @require https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js
// ==/UserScript==

(function() {

    //alert('ati');
    // Your code here...

    //　$(window).load(function(){     });

    function closewx()
    {
        console.log($('#player')[0])
        vid=$('#player').attr("data-video-id")
        console.log("vid:"+vid)
        //http://localhost:8886/?act=tonzhiDownOk&vid=123&urlid=789
        console.log(window.location.search)
        ulrid=encodeURIComponent(window.location.search)
        url= "http://localhost:888/?act=tonzhiDownOk&vid="+vid+"&urlid="+ulrid;
        console.log(url)
        GM.xmlHttpRequest({  method: "GET",    url:url,
                           onload: function(response) {

                               console.log("-------------xmlHttpRequest ret:")
                               console.log([

                                   response.responseText,
                                   response.finalUrl

                               ].join("\n"));
                           }
                          });

        // window.location='http://finishwork';
        // reduce     var alltabNum;
        console.log('localStorage.getItem is:: '+ unsafeWindow. localStorage.getItem('alltabNum'))
        var   alltabNum=parseInt( unsafeWindow.localStorage.getItem('alltabNum'))
        console.log('--cur running num is '+alltabNum)
        if(alltabNum>=1)
        {
            alltabNum--;
            localStorage.setItem('alltabNum',alltabNum)
        }
        window.close()
    }

    setTimeout(function(){

        setTimeout(closewx,3000);



        GM_log("staret  down...")



        GM_log( $('div[data-title="下载这部影片"]' )[0]);
        $('div[data-title="下载这部影片"]' ).click();
        $('div[data-title="下载这部影片"]' )[0].click()


        $('span:contains("下载")').click();
        $('a[class="downloadBtn greyButton"]:last')[0].click()
        GM_log("-------------staret  down end...");








    },7000);

    setTimeout(function(){
        window.close()
    },30*1000);

})();