// ==UserScript==
// @name         testtabs
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.baidu.com/
// @grant GM_log
// @grant GM_getTab
// @grant GM_getTabs
// ==/UserScript==

(function() {
    GM_log("---star");
    console.log("--------------")

   GM_log( window.getBrowser().browsers)

    GM_getTab(function (o) {
    this_tab_data = o;
          console.log(o)
    })

    GM_getTabs(function (db) {
        all_tabs = db;
        console.log(all_tabs)
        for (tab of all_tabs) {
            console.log(tab)
        }
    });
    // Your code here...
})();