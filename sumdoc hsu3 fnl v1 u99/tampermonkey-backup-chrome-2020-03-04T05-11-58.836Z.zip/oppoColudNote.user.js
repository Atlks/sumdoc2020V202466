// ==UserScript==
// @name         oppoColudNote
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://cloud.oppo.com/module.html*
//    https://cloud.oppo.com/module.html*/note
// @require https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js
// ==/UserScript==

(function() {
    console.log( window.location)
    console.log('----oppo page')
    if(window.location.href=='"https://cloud.oppo.com/module.html#/note"')
    {
        // console.log( $('div[class="note-list-items-2ID3T"]') )
        setInterval(function(){
            console.log( $('ul').text())
        },7000);

    }

    if('https://cloud.oppo.com/module.html#/browser'==window.location.href )
    {
         setInterval(function(){
            console.log( $('ul').text())
        },7000);

    }


    // Your code here...
})();