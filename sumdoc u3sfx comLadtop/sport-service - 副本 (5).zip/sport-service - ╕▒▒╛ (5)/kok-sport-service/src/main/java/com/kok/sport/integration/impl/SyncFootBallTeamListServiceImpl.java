package com.kok.sport.integration.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kok.sport.entity.FootballTeam;
import com.kok.sport.integration.SyncFootBallTeamListService;
import com.kok.sport.service.FootballTeamService;
import com.kok.sport.utils.constant.HttpUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 足球球队数据
 */
@Service("syncFootBallTeamListService")
public class SyncFootBallTeamListServiceImpl implements SyncFootBallTeamListService {


    @Autowired
    private FootballTeamService footballTeamService;

    @Override
    public boolean insertFootBallTeam() {
        Map<String,String> map = new HashMap<>();
        map.put("service","Football.Basic.Team_list");
        JSONArray teamData = JSONObject.parseObject(HttpUtil.sendGet(map)).getJSONArray("data");
        List<FootballTeam> list = new ArrayList<>();
        for (int i = 0; i < teamData.size(); i++) {
            JSONObject teamJson =  JSONObject.parseObject(teamData.getString(i));
            FootballTeam footballTeam = new FootballTeam();
            footballTeam.setId(teamJson.getLong("id"));                         //球队Id
            footballTeam.setNameEn(teamJson.getString("name_zh"));               //中文名称
            footballTeam.setShortNameEn(teamJson.getString("short_name_zh"));    //中文名称缩写
            footballTeam.setNameZht(teamJson.getString("name_zht"));             //粤语名称
            footballTeam.setShortNameZht(teamJson.getString("short_name_zht"));  //粤语名称缩写
            footballTeam.setNameEn(teamJson.getString("name_en"));               //英文名称
            footballTeam.setShortNameEn(teamJson.getString("short_name_en"));    //英文名称缩写
            footballTeam.setLogo(teamJson.getString("logo")); //球队logo
            footballTeam.setFound(teamJson.getString("found"));
            footballTeam.setWebSite(teamJson.getString("website"));        //球队官网
            if (teamJson.get("national") == null) {
                footballTeam.setNational(0);
            }else {
                footballTeam.setNational(teamJson.getInteger("national"));
                if (footballTeam.getNational() == 1) {                        //是否是国家队,0否1是
                    footballTeam.setCountryLogo(teamJson.getString("country_logo"));//国家队 logo
                }
            }
            footballTeam.setCreateTime(LocalDateTime.now());              //创建时间
            footballTeam.setDeleteFlag("0");                              //是否删除
            if (footballTeamService.getById(footballTeam.getId()) != null){
                footballTeamService.updateById(footballTeam);
            }else {
                list.add(footballTeam);
            }
        }
        return footballTeamService.saveBatch(list);
    }
}
