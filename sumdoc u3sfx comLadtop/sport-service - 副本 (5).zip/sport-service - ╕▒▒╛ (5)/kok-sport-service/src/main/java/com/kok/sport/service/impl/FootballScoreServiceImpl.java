package com.kok.sport.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.kok.sport.dao.FootballScoreDao;
import com.kok.sport.entity.FootballScore;
import com.kok.sport.service.FootballScoreService;
import org.springframework.stereotype.Service;

/**
 * 足球比赛得分表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@Service("footballScoreService")
public class FootballScoreServiceImpl extends ServiceImpl<FootballScoreDao, FootballScore> implements FootballScoreService {

  /**
   * 足球比赛得分表简单分页查询
   * @param footballScore 足球比赛得分表
   * @return
   */
  @Override
  public IPage<FootballScore> getFootballScorePage(PageVo<FootballScore> pagevo, FootballScore footballScore){
      return baseMapper.getFootballScorePage(pagevo,footballScore);
  }

}
