package com.kok.sport.utils;

import java.util.Set;
import java.util.Map.Entry;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class Util {
	
	public static String processVars(String sql, JsonObject asJsonObject) {

		JsonObject JsonObject1 = asJsonObject;
		// new JsonParser().parse(t).getAsJsonObject();
		Set<Entry<String, JsonElement>> setE = JsonObject1.entrySet();
		for (Entry<String, JsonElement> entry : setE) {
//			System.out.println(entry.getKey());
//			System.out.println(entry.getValue());
			JsonElement value = entry.getValue();
			sql = sql.replace("@" + entry.getKey() + "@", "'" + value.getAsString() + "'");
		}
		return sql;

//        sql = sql.replace("@name_zh@", "'" + item.name_zh + "'")
//
//		        sql = sql.replace("@short_name_zh@", "'" + item.short_name_zh + "'")
//
//				        sql = sql.replace("@name_zht@", "'" + item.name_zht + "'")
//
//						        sql = sql.replace("@short_name_zht@", "'" + item.short_name_zht + "'")
//
//								        sql = sql.replace("@name_en@", "'" + item.name_en + "'")
//
//										        sql = sql.replace("@short_name_en@", "'" + item.short_name_en + "'")
//
//												         sql = sql.replace("@logo@", "'" + item.logo + "'")

		//return null;
	}

}
