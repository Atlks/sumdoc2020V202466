/*
package com.kok.player.feign;

import com.kok.base.config.FeignConfig;
import com.kok.sales.controller.IFeignActivityController;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Lazy;

*/
/**
 * @author haitian
 * 2019年10月13日
 *//*

@FeignClient(value = "sales-service",configuration = {FeignConfig.class})
@Lazy
public interface IActivityFeign extends IFeignActivityController {
}
*/
