package com.kok.sport.utils;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;


//  com.kok.sport.utils.constant.MybatisMapper
@Mapper
public interface MybatisMapper {
	
	//must list map,,if list obj,,only ret firt colume as int
    @Select("select * from football_team_t ${limit}")
    List<Map> football_team_tlist(Map m);

	 
    @Select("select * from Football_Basic_Update_profile ${limit}")
    List<Map> Football_Basic_Update_profile(Map m);

    @Select("select * from Football_Live_Match_list ${limit}")
    List<Map> Football_Live_Match_list(Map m);
}