package com.kok.sport.integration.impl;

import com.kok.sport.integration.SyncMatchDeletedIdsService;
import org.springframework.stereotype.Service;

/**
 * 足球删除比赛数据
 */
@Service("syncMatchDeletedIdService")
public class SyncMatchDeletedIdServiceImpl implements SyncMatchDeletedIdsService {
    /**
     * 拉取足球比赛删除数据
     * @return
     */
    @Override
    public boolean insertMatchDelete() {
        return false;
    }
}
