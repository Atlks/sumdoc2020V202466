package com.kok.sport.utils;

import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

 
 

public class MethodRunner {

	//T(com.kok.sport.utils.CaptchData).m1()  invoke sttatic method
	// T(com.kok.sport.utils.CaptchData).Football_Basic_Update_profile()
	public static void main(String[] args) throws Throwable {
		System.out.println(args[0]);
		System.out.println("d");
		String e=args[0];
		
//		Interpreter i = new Interpreter(); // Construct an interpreter
//		System.out.println(i.eval(" com.kok.sport.utils.CaptchData.m1()  "));
		   ExpressionParser parser = new SpelExpressionParser();

	        Expression exp = parser.parseExpression(e);
	       
	        System.out.println(exp.getValue());
	     

	}

}
