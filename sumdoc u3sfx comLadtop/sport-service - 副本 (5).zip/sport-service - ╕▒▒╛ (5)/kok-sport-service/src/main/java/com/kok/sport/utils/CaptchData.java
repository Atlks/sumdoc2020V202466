package com.kok.sport.utils;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.kok.sport.utils.constant.Httpcliet;
import com.kok.sport.utils.db.UniqueEx;

@SuppressWarnings("all")
public class CaptchData {

	static org.apache.logging.log4j.Logger logger = LogManager.getLogger(CaptchData.class);

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		  Football_Team_list();
		// Football_Basic_Update_profile();
//		Map m=Maps.newConcurrentMap();
//		m.put("k1",111);m.put("k2", 222);
//		String t= new Gson().toJson(m);
//		JsonObject JsonObject1= new JsonParser().parse(t).getAsJsonObject();
//		Set<Entry<String, JsonElement>>  setE=	JsonObject1.entrySet();
//		 for (Entry<String, JsonElement> entry : setE) {
//			System.out.println(entry.getKey());
//			System.out.println(entry.getValue());
//		}
	//	Football_Live_Match_list();
	}

	/*
	 * `id` bigint(19) NOT NULL COMMENT '比赛id', `match_event_id` bigint(19) NOT NULL
	 * COMMENT '赛事id', `match_status` tinyint(3) NOT NULL COMMENT '足球状态码',
	 * `match_time` bigint(19) NOT NULL COMMENT '比赛时间', `tee_time` bigint(19) NOT
	 * NULL COMMENT '开球时间，可能是上/下半场开球时间', `home_id` bigint(19) NOT NULL COMMENT
	 * '主队id', `away_id` bigint(19) NOT NULL COMMENT '客队id', `match_detail`
	 * varchar(100) NOT NULL COMMENT '比赛详细说明，包括加时、点球、中立场、首回合、40分钟赛事 等',
	 * `which_round` int(10) DEFAULT NULL COMMENT '第几轮', `neutral_site` int(10) NOT
	 * NULL COMMENT '是否中立场，1-是 0-否', `animation` int(10) NOT NULL COMMENT
	 * '是否有动画，未购买客户请忽略（1有，0,没有)', `intelligence` int(10) NOT NULL COMMENT
	 * '是否有情报，未购买客户请忽略（1有，0,没有)', `squad` int(10) NOT NULL COMMENT
	 * '是否有阵容，未购买客户请忽略（1有，0,没有)', `video` int(10) NOT NULL COMMENT
	 * '是否有视频，未购买客户请忽略（1有，0,没有)', `create_time` datetime NOT NULL COMMENT '创建时间',
	 * `delete_flag` char(1) NOT NULL COMMENT '是否删除(1.已删除0.未删除)',
	 * 
	 */
	private static void Football_Live_Match_list() throws Exception {

		JsonObject json = getJsonRzt("Football.Live.Match_list");

		Map m = JsonGsonUtil.toMap(json);
		String mts_exp = "#root['data']['matches']";
		List result1 = (List) QlSpelUtil.query(m, mts_exp);
		List MatchItem = (List) result1.get(0);
		Map param = Maps.newConcurrentMap();
		param.put("id", MatchItem.get(0));
		param.put("match_event_id", MatchItem.get(1));
		param.put("match_status", MatchItem.get(2));
		param.put("match_time", MatchItem.get(3));
		param.put("tee_time", MatchItem.get(4));
		param.put("home_id", ((List) MatchItem.get(5)).get(0));
		param.put("away_id", ((List) MatchItem.get(6)).get(0));
		param.put("match_detail", ((List) MatchItem.get(7)).get(0));
		param.put("which_round", ((List) MatchItem.get(7)).get(1));
		param.put("neutral_site", ((List) MatchItem.get(7)).get(2));

		// JsonArray competitons =json.getAsJsonObject("data").
		// getAsJsonObject("delete").getAsJsonArray("competitons");
		String sql = "insert  into Football_MATCH_T(  id,match_event_id, match_status ,match_time,tee_time"
				+ "home_id,away_id,which_round,neutral_site,create_time,delete_flag)values("
				+ "#{[id]},'#{[match_event_id]}','#{[match_status]}','#{[match_time]}','#{[tee_time]}',"
				+ "#{[home_id]},#{[away_id]},#{[which_round]},#{[neutral_site]},now(),0)";
		// sql = processVars(sql, json.getAsJsonObject("data") );
		sql = QlSpelUtil.parse(sql, param);
		logger.info(sql);
		SqlSessionFactory sqlSessionFactory = MybatisUtil.getSqlSessionFactory();

		SqlSession session = sqlSessionFactory.openSession(true);
		// api ��Ϊ[ openSession(boolean autoCommit) ]���ò���ֵ���������Ƹ� sqlSession
		// �Ƿ��Զ��ύ��true��ʾ�Զ��ύ��false��ʾ���Զ��ύ[���޲εķ�������һ�£������Զ��ύ]

		MybatisMapperCls mapper = session.getMapper(MybatisMapperCls.class);

		System.out.println(mapper.update(sql));

	}

	public static String m1() {
		return "000";
	}

	// CaptchData.Football_Basic_Update_profile()
	public static void Football_Basic_Update_profile() throws Exception {
		JsonObject json = getJsonRzt("Football.Basic.Update_profile");

		JsonArray ja = json.getAsJsonObject("data").getAsJsonObject("delete").getAsJsonArray("teams");
		JsonArray competitons = json.getAsJsonObject("data").getAsJsonObject("delete").getAsJsonArray("competitons");
		String sql = "insert  into Football.Basic.Update_profile(  id,data  )values( @id@,'@data@')";
		// sql = processVars(sql, json.getAsJsonObject("data") );
		logger.info(sql);
		SqlSessionFactory sqlSessionFactory = MybatisUtil.getSqlSessionFactory();

		SqlSession session = sqlSessionFactory.openSession(true);
		// api ��Ϊ[ openSession(boolean autoCommit) ]���ò���ֵ���������Ƹ� sqlSession
		// �Ƿ��Զ��ύ��true��ʾ�Զ��ύ��false��ʾ���Զ��ύ[���޲εķ�������һ�£������Զ��ύ]

		MybatisMapperCls mapper = session.getMapper(MybatisMapperCls.class);

		System.out.println(mapper.update(sql));
	}

	public static void Football_Team_list() throws Exception {

		// areas

		// 'Basketball.Basic.Matchevent_list'
		JsonObject json = getJsonRzt("Football.Basic.Team_list");

		// url =
		// "http://www.skrsport.live/?service=Basketball.Basic.Match_deleted_ids&username=sport_api&secret=0gclkqzK";
		JsonArray ja = json.getAsJsonArray("data");

		SqlSessionFactory sqlSessionFactory = MybatisUtil.getSqlSessionFactory();

		SqlSession session = sqlSessionFactory.openSession(true);
		for (JsonElement JsonElement1_item : ja) {

			// item = json.data.teams[fld];
			String id = JsonElement1_item.getAsJsonObject().get("id").getAsString();
			try {
				// logger.info(JsonElement1_item);

				// unique

				MybatisUtil.uniqueIdx("basketball_team_t", "id", id, session);

				String sql = "insert  into football_team_t(  id,name_zh,short_name_zh,name_zht,short_name_zht,name_en,short_name_en,logo ,create_time ,delete_flag )values("
						+ " @id@,@name_zh@,@short_name_zh@,@name_zht@,@short_name_zht@,@name_en@,@short_name_en@,@logo@,now(),0)";
				sql = JsonGsonUtil.processVars(sql, JsonElement1_item.getAsJsonObject());
				logger.info(sql);
				MybatisUtil.execSql(sql, session);
				// var rzt = await query(connection, sql)
				// logger.info(rzt);
				// throw new RuntimeException("d");
			//	Runtime.getRuntime().exit(0);

			} catch (UniqueEx e) {
				try {
					String sql = "update football_team_t set name_en='@name_en@',short_name_en='@short_name_en@',logo='@logo@'  where id="
							+ id;
//							+ "  )values("
//							+ " @id@,@name_zh@,@short_name_zh@,@name_zht@,@short_name_zht@,,@short_name_en@,)";
					sql = JsonGsonUtil.processVars(sql, JsonElement1_item.getAsJsonObject());
					logger.info(sql);
					MybatisUtil.execSql(sql, session);
				} catch (Exception e2) {
					logger.error(e2);
				}
				
			} catch (Throwable e) {
				logger.error(e);

			}
			// break;
			// break;
			// process.exit();
		}

		// basket_match_event_t

		// console.log("f");
	}

	public static JsonObject getJsonRzt(String svr) throws Exception {

		String fname = "d:\\cache\\" + svr + ".json";

		if (new File(fname).exists()) {
			logger.info("file exist " + fname);

			String readFileToString = FileUtils.readFileToString(new File(fname));
			return new JsonParser().parse(readFileToString).getAsJsonObject();

		} else {
			String url = "http://www.skrsport.live/?service=" + svr + "&username=sport_api&secret=0gclkqzK";

//	        const request = require("request");
//	        const util = require('util')
//	        const requestPromise = util.promisify(request);
//	        const response = await requestPromise(url);
//	        console.log('response', response.body);
			String t = Httpcliet.testGet(url);
			// fs.writeFileSync(fname, response.body);
			FileUtils.write(new File(fname), t);
			return new JsonParser().parse(t).getAsJsonObject();
		}

	}

}
