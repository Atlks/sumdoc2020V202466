package com.kok.sport.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.kok.sport.entity.BasketballTeam;
import org.apache.ibatis.annotations.Param;

/**
 * 篮球球队表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface BasketballTeamDao extends BaseMapper<BasketballTeam> {
  /**
    * 篮球球队表简单分页查询
    * @param basketballTeam 篮球球队表
    * @return
    */
  IPage<BasketballTeam> getBasketballTeamPage(PageVo pagevo, @Param("basketballTeam") BasketballTeam basketballTeam);


}
