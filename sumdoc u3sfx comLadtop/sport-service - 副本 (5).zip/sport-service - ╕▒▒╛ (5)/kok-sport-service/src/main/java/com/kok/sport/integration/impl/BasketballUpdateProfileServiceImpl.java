package com.kok.sport.integration.impl;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.kok.sport.dao.BasketMatchEventDao;
import com.kok.sport.dao.BasketballTeamDao;
import com.kok.sport.integration.BasketballTeamService;
import com.kok.sport.integration.BasketballUpdateProfileService;
import com.kok.sport.utils.constant.HttpRequestUtil;
import com.kok.sport.vo.BasketballEventVO;
import com.kok.sport.vo.BasketballTeamVO;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class BasketballUpdateProfileServiceImpl implements BasketballUpdateProfileService {

    private BasketballTeamDao basketballTeamDao;

    private BasketMatchEventDao basketMatchEventDao;

    /**
     * 近2小时内有变动（增、删、改）的球队、赛事信息
     * @return
     */
    @Override
    public boolean basketballUpdateProfileList(String url) {
        //String url = "http://www.skrsport.live/?service=Basketball.Basic.Team_list&username=sport_api&secret=0gclkqzK";
        String result = HttpRequestUtil.doGet(url);
        //解析返回结果
        JSONObject resultObj = JSONObject.parseObject(result);
        if(resultObj.getLong("ret").equals(200)) {
            Map<String, JSONObject> dataMap = JSONObject.parseObject(resultObj.getString("data"), new TypeReference<Map<String, JSONObject>>(){});
            //修改
            Map<String, JSONObject> updateMap = JSONObject.parseObject(dataMap.get("update").toJSONString(), new TypeReference<Map<String, JSONObject>>(){});
            List<JSONObject> updateTeamList = JSONObject.parseObject(updateMap.get("teams").toJSONString(), new TypeReference<List<JSONObject>>(){});
            List<JSONObject> updateCompetitonList = JSONObject.parseObject(updateMap.get("competitons").toJSONString(), new TypeReference<List<JSONObject>>(){});
            if(updateTeamList != null && updateTeamList.size() > 0) {
                List<BasketballTeamVO> teamList = new ArrayList();
                for (JSONObject updateTeam : updateTeamList) {
                    BasketballTeamVO teamVO = new BasketballTeamVO();
                    teamVO.setId(updateTeam.getLong("id"));
                    teamVO.setMatcheventId(updateTeam.getLong("matchevent_id"));
                    teamVO.setConferenceId(updateTeam.getLong("conference_id"));
                    teamVO.setNameZh(updateTeam.getString("name_zh"));
                    teamVO.setNameZht(updateTeam.getString("name_zht"));
                    teamVO.setNameEn(updateTeam.getString("name_en"));
                    teamVO.setShortNameZh(updateTeam.getString("short_name_zh"));
                    teamVO.setShortNameZht(updateTeam.getString("short_name_zht"));
                    teamVO.setShortNameEn(updateTeam.getString("short_name_en"));
                    teamVO.setLogo(updateTeam.getString("logo"));
                    teamList.add(teamVO);
                }
                basketballTeamDao.saveBaskerballTeam(teamList);
            }
            if(updateCompetitonList != null && updateCompetitonList.size() > 0) {
                List<BasketballEventVO> eventList = new ArrayList();
                for (JSONObject updateCompetition : updateCompetitonList) {
                    BasketballEventVO eventVO = new BasketballEventVO();
                    eventVO.setId(updateCompetition.getLong("id"));
                    eventVO.setAreaId(updateCompetition.getLong("area_id "));
                    eventVO.setCountryId(updateCompetition.getLong("country_id"));
                    eventVO.setNameZh(updateCompetition.getString("name_zh"));
                    eventVO.setNameZht(updateCompetition.getString("name_zht"));
                    eventVO.setNameEn(updateCompetition.getString("name_en"));
                    eventVO.setShortNameZh(updateCompetition.getString("short_name_zh"));
                    eventVO.setShortNameZht(updateCompetition.getString("short_name_zht"));
                    eventVO.setShortNameEn(updateCompetition.getString("short_name_en"));
                    eventVO.setLogo(updateCompetition.getString("logo"));
                    eventList.add(eventVO);
                }
                basketMatchEventDao.saveBaskerballEvent(eventList);
            }

            //删除
            Map<String, JSONObject> deleteMap = JSONObject.parseObject(dataMap.get("delete").toJSONString(), new TypeReference<Map<String, JSONObject>>(){});
            List<Long> deleteTeamList = JSONObject.parseObject(deleteMap.get("teams").toJSONString(), new TypeReference<List<Long>>(){});
            List<Long> deleteCompetitonList = JSONObject.parseObject(deleteMap.get("competitons").toJSONString(), new TypeReference<List<Long>>(){});
            if(deleteTeamList != null && deleteTeamList.size() > 0) {
                basketballTeamDao.deleteBaskerballTeam(deleteTeamList);
            }
            if(deleteCompetitonList != null && deleteCompetitonList.size() > 0) {
                basketMatchEventDao.deleteBaskerballEvent(deleteCompetitonList);
            }
            return true;
        }
        return false;
    }
}
