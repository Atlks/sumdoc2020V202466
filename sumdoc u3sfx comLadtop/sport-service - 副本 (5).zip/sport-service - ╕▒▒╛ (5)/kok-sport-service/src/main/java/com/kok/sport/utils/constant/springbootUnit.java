package com.kok.sport.utils.constant;

import com.baomidou.mybatisplus.extension.api.ApiController;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.sql.DriverManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.test.context.web.WebAppConfiguration;

 
@RunWith(SpringRunner.class)
@SpringBootTest
//由于是Web项目，Junit需要模拟ServletContext，因此我们需要给我们的测试类加上@WebAppConfiguration。
@WebAppConfiguration
@MapperScan({"com.kok.sport.utils.constant","com.kfit.user"}) 
public class springbootUnit {
	
	public static void main(String[] args) throws  Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
	Object	conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_demo?useSSL=false&serverTimezone=UTC","root","password");
	
	}
	
	@Autowired
    ApiController ApiController1;
	
	 @Test
	    public void testGetEntFileById(){
		 
		// com.mysql.cj.jdbc.Driver
		 try {
			 
//			System.out.println(ApiController1.getservice("Football.Basic.Team_list",2,5));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      //  Assert.assertSame("企业数量有误",500,entFileService.getCount());
	    }

 
    @Before
    public void init() {
        System.out.println("开始测试-----------------");
    }
    
    
 
    @After
    public void after() {
        System.out.println("测试结束-----------------");
    }
    
}

 