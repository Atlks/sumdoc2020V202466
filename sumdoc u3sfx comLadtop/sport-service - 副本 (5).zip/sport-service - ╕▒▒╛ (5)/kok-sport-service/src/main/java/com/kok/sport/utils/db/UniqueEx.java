package com.kok.sport.utils.db;

public class UniqueEx extends Exception {

	public UniqueEx(String sql) {
		super(sql);
	}

}
