package com.kok.sport.integration.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.kok.sport.integration.SyncMatchEventListService;
import com.kok.sport.utils.constant.HttpUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 足球赛事数据
 */
@Service("syncMatchEventListService")
public class SyncMatchEventListServiceImpl implements SyncMatchEventListService {

    @Autowired
    private FootballMatchEventService footballMatchEventService;

/*    public static void main(String[] args) {
        Map<String,String> map = new HashMap<>();
        map.put("service","Football.Basic.Matchevent_list");
        System.out.println("接口数据"+HttpUtil.sendGet(map));
        JSONArray s = JSONObject.parseObject(JSONObject.parseObject(HttpUtil.sendGet(map)).getString("data")).getJSONArray("matchevents");
        System.out.println("matchevents   ---"+s);
    }*/

    /**
     * 拉取足球赛事数据
     * @return
     */
    @Override
    public boolean insertMarchEvent() {
        Map<String,String> map = new HashMap<>();
        map.put("service","Football.Basic.Matchevent_list");
        JSONArray eventData = JSONObject.parseObject(JSONObject.parseObject(HttpUtil.sendGet(map)).getString("data")).getJSONArray("matchevents");
        List<FootballMatchEvent> list = new ArrayList<>();
        for (int i = 0; i < eventData.size(); i++) {    //赛事数据为 null
            JSONObject eventJson = JSONObject.parseObject(eventData.getString(i));
            FootballMatchEvent footballMatchEvent = new FootballMatchEvent();
            footballMatchEvent.setId(eventJson.getLong("id"));                           //赛事Id
            footballMatchEvent.setSportId(1);                                                 //赛事类型 1-足球，2-篮球
            //测试可用
            footballMatchEvent.setSeasonId(eventJson.getLong("id"));                     //赛季Id
            //
            footballMatchEvent.setAreaId(eventJson.getLong("area_id"));                  //地区Id
            footballMatchEvent.setCountryId(eventJson.getLong("country_id"));            //国家Id
            //
            footballMatchEvent.setLeagueId(eventJson.getLong("id"));                     //联赛Id
            //
            footballMatchEvent.setType(eventJson.getInteger("type"));                    //赛事类型
            footballMatchEvent.setLevel(eventJson.getInteger("level"));                  //忽略兼容使用
            footballMatchEvent.setNameZh(eventJson.getString("name_zh"));                //中文名称
            footballMatchEvent.setShortNameZh(eventJson.getString("short_name_zh"));     //中文名称缩写
            footballMatchEvent.setNameZht(eventJson.getString("name_zht"));              //粤语名称
            footballMatchEvent.setShortNameZht(eventJson.getString("short_name_zht"));   //粤语名称缩写
            footballMatchEvent.setNameEn(eventJson.getString("name_en"));                //英文名称
            footballMatchEvent.setShortNameEn(eventJson.getString("short_name_en"));     //英文名称缩写
            footballMatchEvent.setMatchLogo(eventJson.getString("logo"));                //赛事logo
            footballMatchEvent.setDeleteFlag("0");                                            //是否已删除 0 未删除 1
            footballMatchEvent.setCreateTime(LocalDateTime.now());                            //创建时间

            if (footballMatchEventService.getById(footballMatchEvent.getId()) != null){
                footballMatchEventService.updateById(footballMatchEvent);
            }else {
                list.add(footballMatchEvent);
            }
        }

        return footballMatchEventService.saveBatch(list);
    }
}
