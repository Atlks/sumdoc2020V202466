/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the pig4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */
package com.kok.sport.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 足球比赛环境表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("football_environment_t")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FootballEnvironment extends Model<FootballEnvironment> {

    private static final long serialVersionUID = 1L;

    /**
     * 比赛id
     */
    @TableId
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    /**
     * 比赛id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long matchId;

    /**
     * 气压
     */
    private String pressure;

    /**
     * 温度
     */
    private String temperature;

    /**
     * 风速
     */
    private String wind;

    /**
     * 湿度
     */
    private String humidity;

    /**
     * 天气id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long weatherId;

    /**
     * 天气
     */
    private String weather;

    /**
     * 天气logo
     */
    private String weatherImage;

    /**
     * 创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createTime;

    /**
     * 是否删除(1.已删除0.未删除)
     */
    private String deleteFlag;


}
