package com.kok.sport.vo;


import lombok.Data;

import java.time.LocalTime;

/**
 * 篮球球队VO
 */
@Data
public class BasketballTeamVO {

    /**
     * 球队ID
     */
    private Long id;

    /**
     * 赛事ID
     */
    private Long matcheventId;

    /**
     * 赛区ID
     */
    private Long conferenceId;

    /**
     * 球队中文名字
     */
    private String nameZh;

    /**
     * 球队粤语名字
     */
    private String nameZht;

    /**
     * 球队英文名字
     */
    private String nameEn;

    /**
     * 球队中文简称
     */
    private String shortNameZh;

    /**
     * 球队粤语简称
     */
    private String shortNameZht;

    /**
     * 球队英文简称
     */
    private String shortNameEn;

    /**
     * 球队logo，可能为空
     */
    private String logo;

    /**
     * 创建时间
     */
    private LocalTime createTime;

    /**
     * 是否删除(1.已删除0.未删除)
     */
    private char deleteFlag;

}
