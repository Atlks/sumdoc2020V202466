package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.FootballFormation;

/**
 * 足球比赛阵型表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface FootballFormationService extends IService<FootballFormation> {

  /**
   * 足球比赛阵型表简单分页查询
   * @param footballFormation 足球比赛阵型表
   * @return
   */
  IPage<FootballFormation> getFootballFormationPage(PageVo<FootballFormation> pagevo, FootballFormation footballFormation);


}
