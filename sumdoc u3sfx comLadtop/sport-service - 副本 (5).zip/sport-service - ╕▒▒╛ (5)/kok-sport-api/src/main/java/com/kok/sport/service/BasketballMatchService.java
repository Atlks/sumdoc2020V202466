package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.BasketballMatch;

/**
 * 篮球比赛表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface BasketballMatchService extends IService<BasketballMatch> {

  /**
   * 篮球比赛表简单分页查询
   * @param basketballMatch 篮球比赛表
   * @return
   */
  IPage<BasketballMatch> getBasketballMatchPage(PageVo<BasketballMatch> pagevo, BasketballMatch basketballMatch);


}
