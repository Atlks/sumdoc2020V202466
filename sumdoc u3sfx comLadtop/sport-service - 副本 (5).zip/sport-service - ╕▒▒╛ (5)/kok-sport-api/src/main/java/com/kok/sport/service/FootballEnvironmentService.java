package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.FootballEnvironment;

/**
 * 足球比赛环境表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface FootballEnvironmentService extends IService<FootballEnvironment> {

  /**
   * 足球比赛环境表简单分页查询
   * @param footballEnvironment 足球比赛环境表
   * @return
   */
  IPage<FootballEnvironment> getFootballEnvironmentPage(PageVo<FootballEnvironment> pagevo, FootballEnvironment footballEnvironment);


}
