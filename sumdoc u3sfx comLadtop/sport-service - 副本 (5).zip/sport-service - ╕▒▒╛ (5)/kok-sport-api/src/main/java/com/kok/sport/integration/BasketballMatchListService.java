package com.kok.sport.integration;

public interface BasketballMatchListService {

    /**
     * 前后30天的全量赛程赛果数据,及赛程中比赛涉及到的球队及赛事信息
     * @return
     */
    boolean basketballMatchList(String url);
}
