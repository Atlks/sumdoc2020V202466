/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the pig4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */
package com.kok.sport.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 足球比赛表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("football_match_t")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FootballMatch extends Model<FootballMatch> {

    private static final long serialVersionUID = 1L;

    /**
     * 比赛id
     */
    @TableId
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    /**
     * 赛事id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long matchEventId;

    /**
     * 足球状态码
     */
    private Integer matchStatus;

    /**
     * 比赛时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long matchTime;

    /**
     * 开球时间，可能是上/下半场开球时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long teeTime;

    /**
     * 主队id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long homeId;

    /**
     * 客队id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long awayId;

    /**
     * 比赛详细说明，包括加时、点球、中立场、首回合、40分钟赛事 等
     */
    private String matchDetail;

    /**
     * 第几轮
     */
    private Integer whichRound;

    /**
     * 是否中立场，1-是 0-否
     */
    private Integer neutralSite;

    /**
     * 是否有动画，未购买客户请忽略（1有，0,没有)
     */
    private Integer animation;

    /**
     * 是否有情报，未购买客户请忽略（1有，0,没有)
     */
    private Integer intelligence;

    /**
     * 是否有阵容，未购买客户请忽略（1有，0,没有)
     */
    private Integer squad;

    /**
     * 是否有视频，未购买客户请忽略（1有，0,没有)
     */
    private Integer video;

    /**
     * 创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createTime;

    /**
     * 是否删除(1.已删除0.未删除)
     */
    private String deleteFlag;


}
