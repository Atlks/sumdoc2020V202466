package com.kok.sport.integration;

public interface BasketballUpdateProfileService {

    /**
     * 近2小时内有变动（增、删、改）的球队、赛事信息
     * @return
     */
    boolean basketballUpdateProfileList(String url);
}
