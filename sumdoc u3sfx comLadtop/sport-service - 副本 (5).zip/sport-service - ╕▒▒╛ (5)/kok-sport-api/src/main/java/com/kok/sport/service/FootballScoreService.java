package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.FootballScore;

/**
 * 足球比赛得分表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface FootballScoreService extends IService<FootballScore> {

  /**
   * 足球比赛得分表简单分页查询
   * @param footballScore 足球比赛得分表
   * @return
   */
  IPage<FootballScore> getFootballScorePage(PageVo<FootballScore> pagevo, FootballScore footballScore);


}
