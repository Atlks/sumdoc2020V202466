package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.base.vo.PageVo;
import com.kok.sport.entity.KokMatchStream;

/**
* <p>
* 比赛直播数据源表 服务类
* </p>
*
* @author martin
* @since 2020-03-11
*/
public interface KokMatchStreamService extends IService<KokMatchStream> {

    /**
     * 比赛直播源表简单分页查询
     * @param kokMatchStream 比赛直播源表
     * @return
     */
    IPage<KokMatchStream> getKokMatchStreamPage(PageVo<KokMatchStream> pageVo, KokMatchStream kokMatchStream);

    /**
     * 比赛直播源删除
     * @param id
     * @return
     */
    boolean removeKokMatchStream(Long id);
}
