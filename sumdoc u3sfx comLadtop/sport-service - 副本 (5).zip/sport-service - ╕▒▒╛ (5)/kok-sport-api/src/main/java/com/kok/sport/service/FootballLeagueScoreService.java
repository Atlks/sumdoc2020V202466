package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.FootballLeagueScore;

/**
 * 足球联赛积分表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface FootballLeagueScoreService extends IService<FootballLeagueScore> {

  /**
   * 足球联赛积分表简单分页查询
   * @param footballLeagueScore 足球联赛积分表
   * @return
   */
  IPage<FootballLeagueScore> getFootballLeagueScorePage(PageVo<FootballLeagueScore> pagevo, FootballLeagueScore footballLeagueScore);


}
