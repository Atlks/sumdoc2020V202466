package com.kok.sport.dto;

import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.kok.base.vo.PageVo;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * @author: Gray
 * @create: 2020-03-13 13:30
 **/
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("比赛信息查询对象")
public class KokMatchDto extends PageVo {

    /**
     * 主键id
     */
    private Long id;

    /**
     * 比赛类型
     */
    private String matchType;

    /**
     * 比赛时间
     */
    private String matchTime;

    /**
     * 主队名称
     */
    private String homeTeam;

    /**
     * 客队名称
     */
    private String awayTeam;

    /**
     * 比赛信息的md5值
     */
    private String md5key;

    /**
     * 比赛开始时间
     */
    private LocalDateTime startTime;

    /**
     * 比赛结束时间
     */
    private LocalDateTime endTime;

    /**
     * 比赛状态
     */
    private String matchStatus;
}
