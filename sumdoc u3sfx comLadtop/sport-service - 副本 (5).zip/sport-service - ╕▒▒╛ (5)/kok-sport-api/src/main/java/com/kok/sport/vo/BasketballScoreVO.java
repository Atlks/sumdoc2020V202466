package com.kok.sport.vo;


import lombok.Data;

import java.time.LocalTime;

/**
 * 篮球比赛得分VO
 */
@Data
public class BasketballScoreVO {

    /**
     * 主键id
     */
    private Long id;
    /**
     * 比赛id
     */
    private Long matchId;
    /**
     * 球队id
     */
    private Long teamId;
    /**
     * 1-主队 2-客队
     */
    private Long teamType;
    /**
     * 比赛状态
     */
    private Long matchStatus;
    /**
     * 实时时间
     */
    private Long time;
    /**
     * 第1节分数
     */
    private Long firstSectionScores;
    /**
     * 第2节分数
     */
    private Long secondSectionScores;
    /**
     * 第3节分数
     */
    private Long thirdSectionScores;
    /**
     * 第4节分数
     */
    private Long fourthSectionScores;
    /**
     * 加时分数
     */
    private Long overtimeScores;
    /**
     * 创建时间
     */
    private LocalTime createTime;
    /**
     * 是否删除(1.已删除0.未删除)
     */
    private char deleteFlag;
}
