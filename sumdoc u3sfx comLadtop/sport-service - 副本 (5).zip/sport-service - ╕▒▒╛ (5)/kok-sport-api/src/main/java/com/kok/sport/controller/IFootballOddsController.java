package com.kok.sport.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.exception.ApplicationException;
import com.kok.base.vo.PageVo;
import com.kok.sport.entity.FootballOdds;
import org.springframework.web.bind.annotation.*;
import com.kok.base.utils.Result;

/**
 * 足球盘口指数表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@RequestMapping("/footballodds")
public interface IFootballOddsController {

  /**
   * 简单分页查询
   * @param pagevo 分页对象
   * @param footballOdds 足球盘口指数表
   * @return
   */
  @GetMapping("/list")
  Result<IPage<FootballOdds>> getFootballOddsPage(PageVo<FootballOdds> pagevo, FootballOdds footballOdds) throws ApplicationException;


  /**
   * 通过id查询单条记录
   * @param id
   * @return R
   */
  @GetMapping("/view/{id}")
  Result<FootballOdds> getById(@PathVariable("id") Long id) throws ApplicationException;

  /**
   * 新增记录
   * @param footballOdds
   * @return R
   */
  @PostMapping("/add")
  Result save(@RequestBody FootballOdds footballOdds) throws ApplicationException;

  /**
   * 修改记录
   * @param footballOdds
   * @return R
   */
  @PostMapping("/edit")
  Result update(@RequestBody FootballOdds footballOdds) throws ApplicationException;

  /**
   * 通过id删除一条记录
   * @param id
   * @return R
   */
  @GetMapping("/delete/{id}")
  Result removeById(@PathVariable Long id) throws ApplicationException;

}
