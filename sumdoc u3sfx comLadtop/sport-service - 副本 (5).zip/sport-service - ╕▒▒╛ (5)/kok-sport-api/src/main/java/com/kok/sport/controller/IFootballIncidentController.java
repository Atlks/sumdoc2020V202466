package com.kok.sport.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.exception.ApplicationException;
import com.kok.base.vo.PageVo;
import com.kok.sport.entity.FootballIncident;
import org.springframework.web.bind.annotation.*;
import com.kok.base.utils.Result;

/**
 * 比赛发生事件表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@RequestMapping("/footballincident")
public interface IFootballIncidentController {

  /**
   * 简单分页查询
   * @param pagevo 分页对象
   * @param footballIncident 比赛发生事件表
   * @return
   */
  @GetMapping("/list")
  Result<IPage<FootballIncident>> getFootballIncidentPage(PageVo<FootballIncident> pagevo, FootballIncident footballIncident) throws ApplicationException;


  /**
   * 通过id查询单条记录
   * @param id
   * @return R
   */
  @GetMapping("/view/{id}")
  Result<FootballIncident> getById(@PathVariable("id") Long id) throws ApplicationException;

  /**
   * 新增记录
   * @param footballIncident
   * @return R
   */
  @PostMapping("/add")
  Result save(@RequestBody FootballIncident footballIncident) throws ApplicationException;

  /**
   * 修改记录
   * @param footballIncident
   * @return R
   */
  @PostMapping("/edit")
  Result update(@RequestBody FootballIncident footballIncident) throws ApplicationException;

  /**
   * 通过id删除一条记录
   * @param id
   * @return R
   */
  @GetMapping("/delete/{id}")
  Result removeById(@PathVariable Long id) throws ApplicationException;

}
