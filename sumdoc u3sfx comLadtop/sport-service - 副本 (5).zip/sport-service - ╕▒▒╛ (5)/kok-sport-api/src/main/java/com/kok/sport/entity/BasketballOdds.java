/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the pig4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */
package com.kok.sport.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.math.BigDecimal;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 篮球盘口指数表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("basketball_odds_t")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BasketballOdds extends Model<BasketballOdds> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    /**
     * 公司id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long companyId;

    /**
     * 比赛id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long matcheId;

    /**
     * 指数类型:1,asia-亚盘; 2,bs-大小球;3,eu-欧赔
     */
    private Integer oddsType;

    /**
     * 变化时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long changeTime;

    /**
     * 比赛进行时间
     */
    private String happenTime;

    /**
     * 比赛状态
     */
    private Integer matchStatus;

    /**
     * 主赔率
     */
    private BigDecimal homeOdds;

    /**
     * 盘口/和局赔率
     */
    private BigDecimal tieOdds;

    /**
     * 客赔率
     */
    private BigDecimal awayOdds;

    /**
     * 是否封盘 0-否,1-是
     */
    private Integer lockFlag;

    /**
     * 实时比分
     */
    private String realTimeScore;

    /**
     * 创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createTime;

    /**
     * 是否删除(1.已删除0.未删除)
     */
    private String deleteFlag;


}
