package com.kok.sport.integration;

/**
 * 足球球队
 */
public interface SyncFootBallTeamListService {
    /**
     * 拉取足球球队api接口数据
     */
    boolean insertFootBallTeam();
}
