package com.kok.sport.vo;


import lombok.Data;

import java.time.LocalTime;

/**
 * 篮球赛事VO
 */
@Data
public class BasketballEventVO {

    /**
     * 赛事ID
     */
    private Long id;

    /**
     * 地区ID
     */
    private Long areaId;

    /**
     * 国家ID
     */
    private Long countryId;

    /**
     * 赛事类型 1-常规赛 2-季后赛 3-季前赛 4-全明星 5-杯赛
     */
    private Long matchType;

    /**
     * 赛事中文名字
     */
    private String nameZh;

    /**
     * 赛事粤语名字
     */
    private String nameZht;

    /**
     * 赛事英文名字
     */
    private String nameEn;

    /**
     * 赛事中文简称
     */
    private String shortNameZh;

    /**
     * 赛事粤语简称
     */
    private String shortNameZht;

    /**
     * 赛事英文简称
     */
    private String shortNameEn;

    /**
     * 赛事logo，可能为空
     */
    private String logo;

    /**
     * 创建时间
     */
    private LocalTime createTime;

    /**
     * 是否删除(1.已删除0.未删除)
     */
    private char deleteFlag;

}
