package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.SysArea;

/**
 * 区域表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface SysAreaService extends IService<SysArea> {

  /**
   * 区域表简单分页查询
   * @param sysArea 区域表
   * @return
   */
  IPage<SysArea> getSysAreaPage(PageVo<SysArea> pagevo, SysArea sysArea);


}
