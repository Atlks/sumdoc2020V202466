/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the pig4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */
package com.kok.sport.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 篮球赛事表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("basketball_event_t")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BasketballEvent extends Model<BasketballEvent> {

    private static final long serialVersionUID = 1L;

    /**
     * 赛事id
     */
    @TableId
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    /**
     * 地区id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long areaId;

    /**
     * 国家id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long countryId;

    /**
     * 赛事类型 1-常规赛 2-季后赛 3-季前赛 4-全明星 5-杯赛
     */
    private Integer matchType;

    /**
     * 中文
     */
    private String nameZh;

    /**
     * 中文缩写
     */
    private String shortNameZh;

    /**
     * 粤语
     */
    private String nameZht;

    /**
     * 粤语缩写
     */
    private String shortNameZht;

    /**
     * 英文
     */
    private String nameEn;

    /**
     * 英文缩写
     */
    private String shortNameEn;

    /**
     * 赛事logo
     */
    private String matchLogo;

    /**
     * 是否删除(1.已删除0.未删除)
     */
    private String deleteFlag;

    /**
     * 创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createTime;


}
