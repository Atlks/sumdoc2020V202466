package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.MatchSeason;

/**
 * 赛季信息表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface MatchSeasonService extends IService<MatchSeason> {

  /**
   * 赛季信息表简单分页查询
   * @param matchSeason 赛季信息表
   * @return
   */
  IPage<MatchSeason> getMatchSeasonPage(PageVo<MatchSeason> pagevo, MatchSeason matchSeason);


}
