package com.kok.sport.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 比赛直播数据源表
 * </p>
 *
 * @author martin
 * @since 2020-03-11
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("kok_match_stream_t")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KokMatchStream extends Model<KokMatchStream> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    /**
     * 比赛id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long matchId;

    /**
     * 比赛直播地址
     */
    private String streamUrl;

}
