package com.kok.sport.vo;


import lombok.Data;

import java.time.LocalTime;

/**
 * 篮球赛事阶段VO
 */
@Data
public class BasketballStageVO {

    /**
     * 赛事阶段ID
     */
    private Long id;

    /**
     * 赛事阶段中文名字
     */
    private String nameZh;

    /**
     * 赛事阶段粤语名字
     */
    private String nameZht;

    /**
     * 赛事阶段英文名字
     */
    private String nameEn;

    /**
     * 创建时间
     */
    private LocalTime createTime;

    /**
     * 是否删除(1.已删除0.未删除)
     */
    private char deleteFlag;

}
