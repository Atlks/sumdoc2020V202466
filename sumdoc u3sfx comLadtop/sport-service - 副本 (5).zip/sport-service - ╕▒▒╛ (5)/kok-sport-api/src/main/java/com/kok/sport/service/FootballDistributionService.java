package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.FootballDistribution;

/**
 * 足球进球分布表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface FootballDistributionService extends IService<FootballDistribution> {

  /**
   * 足球进球分布表简单分页查询
   * @param footballDistribution 足球进球分布表
   * @return
   */
  IPage<FootballDistribution> getFootballDistributionPage(PageVo<FootballDistribution> pagevo, FootballDistribution footballDistribution);


}
