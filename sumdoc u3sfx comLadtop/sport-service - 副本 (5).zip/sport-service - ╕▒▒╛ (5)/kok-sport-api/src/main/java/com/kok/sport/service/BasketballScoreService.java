package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.BasketballScore;

/**
 * 篮球比赛得分表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface BasketballScoreService extends IService<BasketballScore> {

  /**
   * 篮球比赛得分表简单分页查询
   * @param basketballScore 篮球比赛得分表
   * @return
   */
  IPage<BasketballScore> getBasketballScorePage(PageVo<BasketballScore> pagevo, BasketballScore basketballScore);


}
