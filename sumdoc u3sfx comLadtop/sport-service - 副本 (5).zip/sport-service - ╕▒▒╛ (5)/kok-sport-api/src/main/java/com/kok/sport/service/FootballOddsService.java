package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.FootballOdds;

/**
 * 足球盘口指数表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface FootballOddsService extends IService<FootballOdds> {

  /**
   * 足球盘口指数表简单分页查询
   * @param footballOdds 足球盘口指数表
   * @return
   */
  IPage<FootballOdds> getFootballOddsPage(PageVo<FootballOdds> pagevo, FootballOdds footballOdds);


}
