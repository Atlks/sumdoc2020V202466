package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.BasketballTeamPlayer;

/**
 * 篮球球员表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface BasketballTeamPlayerService extends IService<BasketballTeamPlayer> {

  /**
   * 篮球球员表简单分页查询
   * @param basketballTeamPlayer 篮球球员表
   * @return
   */
  IPage<BasketballTeamPlayer> getBasketballTeamPlayerPage(PageVo<BasketballTeamPlayer> pagevo, BasketballTeamPlayer basketballTeamPlayer);


}
