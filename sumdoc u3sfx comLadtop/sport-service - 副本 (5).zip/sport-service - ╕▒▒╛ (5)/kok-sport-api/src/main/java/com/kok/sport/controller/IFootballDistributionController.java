package com.kok.sport.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.exception.ApplicationException;
import com.kok.base.vo.PageVo;
import com.kok.sport.entity.FootballDistribution;
import org.springframework.web.bind.annotation.*;
import com.kok.base.utils.Result;

/**
 * 足球进球分布表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@RequestMapping("/footballdistribution")
public interface IFootballDistributionController {

  /**
   * 简单分页查询
   * @param pagevo 分页对象
   * @param footballDistribution 足球进球分布表
   * @return
   */
  @GetMapping("/list")
  Result<IPage<FootballDistribution>> getFootballDistributionPage(PageVo<FootballDistribution> pagevo, FootballDistribution footballDistribution) throws ApplicationException;


  /**
   * 通过id查询单条记录
   * @param id
   * @return R
   */
  @GetMapping("/view/{id}")
  Result<FootballDistribution> getById(@PathVariable("id") Long id) throws ApplicationException;

  /**
   * 新增记录
   * @param footballDistribution
   * @return R
   */
  @PostMapping("/add")
  Result save(@RequestBody FootballDistribution footballDistribution) throws ApplicationException;

  /**
   * 修改记录
   * @param footballDistribution
   * @return R
   */
  @PostMapping("/edit")
  Result update(@RequestBody FootballDistribution footballDistribution) throws ApplicationException;

  /**
   * 通过id删除一条记录
   * @param id
   * @return R
   */
  @GetMapping("/delete/{id}")
  Result removeById(@PathVariable Long id) throws ApplicationException;

}
