package com.kok.sport.integration;

/**
 * 足球删除比赛
 */
public interface SyncMatchDeletedIdsService {
    /**
     * 拉取足球删除比赛数据
     */
    boolean insertMatchDelete();

}
