package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.dto.KokMatchDto;
import com.kok.sport.entity.KokMatch;
import com.kok.sport.vo.KokMatchVO;

/**
* <p>
* 比赛信息基础表 服务类
* </p>
*
* @author martin
* @since 2020-03-11
*/
public interface KokMatchService extends IService<KokMatch> {

    /**
     * 简单分页查询
     * @param kokMatchDto 足球比赛查询对象
     * @return
     */
    IPage<KokMatchVO> getKokMatchPage(KokMatchDto kokMatchDto);
}
