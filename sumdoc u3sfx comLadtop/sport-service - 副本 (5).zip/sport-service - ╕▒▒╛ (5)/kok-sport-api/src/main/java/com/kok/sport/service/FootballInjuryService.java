package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.FootballInjury;

/**
 * 足球比赛伤停情况表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface FootballInjuryService extends IService<FootballInjury> {

  /**
   * 足球比赛伤停情况表简单分页查询
   * @param footballInjury 足球比赛伤停情况表
   * @return
   */
  IPage<FootballInjury> getFootballInjuryPage(PageVo<FootballInjury> pagevo, FootballInjury footballInjury);


}
