package com.kok.sport.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.exception.ApplicationException;
import com.kok.base.vo.PageVo;
import com.kok.sport.entity.MatchSeason;
import org.springframework.web.bind.annotation.*;
import com.kok.base.utils.Result;

/**
 * 赛季信息表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@RequestMapping("/matchseason")
public interface IMatchSeasonController {

  /**
   * 简单分页查询
   * @param pagevo 分页对象
   * @param matchSeason 赛季信息表
   * @return
   */
  @GetMapping("/list")
  Result<IPage<MatchSeason>> getMatchSeasonPage(PageVo<MatchSeason> pagevo, MatchSeason matchSeason) throws ApplicationException;


  /**
   * 通过id查询单条记录
   * @param id
   * @return R
   */
  @GetMapping("/view/{id}")
  Result<MatchSeason> getById(@PathVariable("id") Long id) throws ApplicationException;

  /**
   * 新增记录
   * @param matchSeason
   * @return R
   */
  @PostMapping("/add")
  Result save(@RequestBody MatchSeason matchSeason) throws ApplicationException;

  /**
   * 修改记录
   * @param matchSeason
   * @return R
   */
  @PostMapping("/edit")
  Result update(@RequestBody MatchSeason matchSeason) throws ApplicationException;

  /**
   * 通过id删除一条记录
   * @param id
   * @return R
   */
  @GetMapping("/delete/{id}")
  Result removeById(@PathVariable Long id) throws ApplicationException;

}
