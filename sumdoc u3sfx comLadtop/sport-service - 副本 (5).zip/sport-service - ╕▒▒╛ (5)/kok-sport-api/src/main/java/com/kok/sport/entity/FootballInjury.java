/*
 *    Copyright (c) 2018-2025, lengleng All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * Neither the name of the pig4cloud.com developer nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 * Author: lengleng (wangiegie@gmail.com)
 */
package com.kok.sport.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 足球比赛伤停情况表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("football_injury_t")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FootballInjury extends Model<FootballInjury> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    /**
     * 比赛id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long matchId;

    /**
     * 1:主队；2:客队
     */
    private Integer teamType;

    /**
     * 球员id
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long playerId;

    /**
     * 球员名称
     */
    private String playerName;

    /**
     * 球员logo
     */
    private String logo;

    /**
     * 球员位置
     */
    private String position;

    /**
     * 伤停原因
     */
    private String reason;

    /**
     * 影响场次
     */
    private Integer missedMatches;

    /**
     * 开始时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long startTime;

    /**
     * 归队时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long endTime;

    /**
     * 0-未知 1-受伤 2-停赛
     */
    private Integer type;

    /**
     * 创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class, as = LocalDateTime.class)
    private LocalDateTime createTime;

    /**
     * 是否删除(1.已删除0.未删除)
     */
    private String deleteFlag;


}
