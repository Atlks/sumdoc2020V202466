package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.BasketballOdds;

/**
 * 篮球盘口指数表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface BasketballOddsService extends IService<BasketballOdds> {

  /**
   * 篮球盘口指数表简单分页查询
   * @param basketballOdds 篮球盘口指数表
   * @return
   */
  IPage<BasketballOdds> getBasketballOddsPage(PageVo<BasketballOdds> pagevo, BasketballOdds basketballOdds);


}
