package com.kok.sport.integration;

/**
 * 足球赛事资料
 */
public interface SyncMatchEventListService {

    /**
     * 拉取足球赛事数据
     * @return
     */
    boolean insertMarchEvent();

}
