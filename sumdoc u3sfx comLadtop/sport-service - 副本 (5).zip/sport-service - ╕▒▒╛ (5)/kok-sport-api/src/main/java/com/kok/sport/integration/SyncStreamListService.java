package com.kok.sport.integration;

/**
 * 比赛视频直播流同步接口
 */
public interface SyncStreamListService {

    /**
     * 拉取比赛视频数据
     */
    public boolean insertVideoApi();

    /**
     * 篮球比赛详情---返回具体一场比赛的比赛环境、文字直播、技术统计信息；
     */
    public boolean matchDetail(String matchId)throws Exception;

    /**
     * 篮球删除数据
     */
    public boolean matchDelete()throws Exception;

    /**
     * 篮球赛事资料
     */
    public boolean matchEvent()throws Exception;
}
