package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.FootballMatch;

/**
 * 足球比赛表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface FootballMatchService extends IService<FootballMatch> {

  /**
   * 足球比赛表简单分页查询
   * @param footballMatch 足球比赛表
   * @return
   */
  IPage<FootballMatch> getFootballMatchPage(PageVo<FootballMatch> pagevo, FootballMatch footballMatch);


}
