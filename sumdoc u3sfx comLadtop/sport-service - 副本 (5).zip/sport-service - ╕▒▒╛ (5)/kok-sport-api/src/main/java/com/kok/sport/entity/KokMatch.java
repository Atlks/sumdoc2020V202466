package com.kok.sport.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * <p>
 * 比赛信息基础表
 * </p>
 *
 * @author martin
 * @since 2020-03-11
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("kok_match_t")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KokMatch extends Model<KokMatch> {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    /**
     * 比赛类型
     */
    private String matchType;

    /**
     * 比赛时间
     */
    private String matchTime;

    /**
     * 主队名称
     */
    private String homeTeam;

    /**
     * 客队名称
     */
    private String awayTeam;

    /**
     * 比赛信息的md5值
     */
    private String md5key;

    /**
     * 比赛开始时间
     */
    private LocalDateTime startTime;

    /**
     * 比赛结束时间
     */
    private LocalDateTime endTime;

    /**
     * 比赛状态
     */
    private String matchStatus;

}
