package com.kok.sport.integration;

public interface BasketballTeamService {

    /**
     * 篮球球队信息
     * @return 球队列表
     */
    boolean basketballTeamList(String url);
}
