package com.kok.sport.vo;

/**
 * 比赛视频源
 */
public class MatchStreamTVO {
}
