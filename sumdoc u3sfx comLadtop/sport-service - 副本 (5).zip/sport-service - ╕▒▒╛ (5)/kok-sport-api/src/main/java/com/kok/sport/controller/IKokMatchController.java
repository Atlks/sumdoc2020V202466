package com.kok.sport.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.exception.ApplicationException;
import com.kok.base.utils.Result;
import com.kok.base.vo.PageVo;
import com.kok.sport.dto.KokMatchDto;
import com.kok.sport.entity.KokMatch;
import com.kok.sport.vo.KokMatchVO;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

/**
 * KOK看球比赛
 * @author martin
 * @date 2020-03-12 15:07:30
 */
@RequestMapping(value = "/sport/kokMatch", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public interface IKokMatchController {

  /**
   * 简单分页查询
   * @param kokMatchDto 足球比赛查询对象
   * @return
   */
  @GetMapping("/list")
  Result<IPage<KokMatchVO>> getKokMatchPage(KokMatchDto kokMatchDto) throws ApplicationException;

  /**
   * 通过id查询单条记录
   * @param id
   * @return R
   */
  @GetMapping("/view/{id}")
  Result<KokMatch> getById(@PathVariable("id") Long id) throws ApplicationException;

  /**
   * 新增记录
   * @param kokMatch
   * @return R
   */
  @PostMapping("/add")
  Result save(@RequestBody KokMatch kokMatch) throws ApplicationException;

  /**
   * 修改记录
   * @param kokMatch
   * @return R
   */
  @PostMapping("/edit")
  Result update(@RequestBody KokMatch kokMatch) throws ApplicationException;

  /**
   * 通过id删除一条记录
   * @param id
   * @return R
   */
  @GetMapping("/delete/{id}")
  Result removeById(@PathVariable Long id) throws ApplicationException;

}
