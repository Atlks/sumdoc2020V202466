package com.kok.sport.vo;


import lombok.Data;

import java.time.LocalTime;

/**
 * 篮球比赛VO
 */
@Data
public class BasketballMatchVO {

    /**
     * 比赛id
     */
    private Long id;
    /**
     * 赛事id
     */
    private Long matchEventId;
    /**
     * 赛季id
     */
    private Long seasonId;
    /**
     * 队段id
     */
    private Long stagesId;
    /**
     * 主队id
     */
    private Long homeId;
    /**
     * 客队id
     */
    private Long awayId;
    /**
     * 比赛类型 1-常规赛 2-季后赛 3-季前赛 4-全明星 5-杯赛
     */
    private Long matchType;
    /**
     * 比赛总节数
     */
    private Long totalSections;
    /**
     * 篮球状态码
     */
    private Long matchStatus;
    /**
     * 比赛时间
     */
    private Long matchTime;
    /**
     * 当前总秒钟数，显示转换成 mm:ss
     */
    private Long currentTotalSeconds;
    /**
     * 比赛详细说明
     */
    private String matchDetail;
    /**
     * 兼容,请忽略
     */
    private String compatible;
    /**
     * 是否有动画
     */
    private Long animation;
    /**
     * 是否有情报
     */
    private Long intelligence;
    /**
     * 创建时间
     */
    private LocalTime createTime;
    /**
     * 是否删除(1.已删除0.未删除)
     */
    private char deleteFlag;
}
