package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.BasketballStage;

/**
 * 篮球比赛阶段表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface BasketballStageService extends IService<BasketballStage> {

  /**
   * 篮球比赛阶段表简单分页查询
   * @param basketballStage 篮球比赛阶段表
   * @return
   */
  IPage<BasketballStage> getBasketballStagePage(PageVo<BasketballStage> pagevo, BasketballStage basketballStage);


}
