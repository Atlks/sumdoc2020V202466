package com.kok.sport.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.kok.base.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.kok.sport.entity.FootballPlayerIncident;

/**
 * 足球比赛球员事件表
 *
 * @author martin
 * @date 2020-03-28 00:59:47
 */
public interface FootballPlayerIncidentService extends IService<FootballPlayerIncident> {

  /**
   * 足球比赛球员事件表简单分页查询
   * @param footballPlayerIncident 足球比赛球员事件表
   * @return
   */
  IPage<FootballPlayerIncident> getFootballPlayerIncidentPage(PageVo<FootballPlayerIncident> pagevo, FootballPlayerIncident footballPlayerIncident);


}
